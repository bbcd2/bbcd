import{a as t}from"../chunks/entry.UZtmvIbS.js";export{t as start};
