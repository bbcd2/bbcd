

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.DuRH5mL0.js","_app/immutable/chunks/scheduler.DMUGxSNz.js","_app/immutable/chunks/index.DtO2d7cD.js"];
export const stylesheets = [];
export const fonts = [];
