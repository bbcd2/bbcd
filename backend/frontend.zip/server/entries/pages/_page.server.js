import axios from "axios";
const actions = {
  default: async ({ request }) => {
    const data = await request.formData();
    const channel = data.get("channel");
    const startTimestamp = Math.floor(
      (/* @__PURE__ */ new Date(data.get("startDate") + "T" + data.get("startTime"))).getTime() / 1e3
    );
    const endTimestamp = Math.floor(
      (/* @__PURE__ */ new Date(data.get("endDate") + "T" + data.get("endTime"))).getTime() / 1e3
    );
    console.log("startTimestamp:", startTimestamp);
    if (startTimestamp > endTimestamp) {
      return { status: 400, body: "Invalid timestamps" };
    }
    if (startTimestamp > Date.now() / 1e3 || endTimestamp > Date.now() / 1e3) {
      return { status: 400, body: "Invalid timestamps" };
    }
    if (endTimestamp - startTimestamp > 3600) {
      return { status: 400, body: "Invalid timestamps" };
    }
    const now = /* @__PURE__ */ new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    console.log("entering time loop");
    if (hours > 22 || hours === 22 && minutes >= 45 || hours < 7 || hours === 7 && minutes < 15) {
      console.log("contacting local server");
      const response = await axios.post("http://127.0.0.1:3001/downloadVideo", {
        startTimestamp,
        endTimestamp,
        channel
      });
      return { status: 200, body: await response.data };
    } else {
      console.log("contacting hp");
      const response = await axios.post("http://100.64.1.3:3001/downloadVideo", {
        startTimestamp,
        endTimestamp,
        channel
      });
      return { status: 200, body: await response.data };
    }
  }
};
export {
  actions
};
