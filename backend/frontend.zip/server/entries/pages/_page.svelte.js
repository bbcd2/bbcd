import { c as create_ssr_component, i as is_promise, n as noop, d as each, e as escape } from "../../chunks/ssr.js";
import { createClient } from "@supabase/supabase-js";
function statusString(status) {
  switch (status) {
    case 1:
      return "Initialising";
    case 2:
      return "Downloading Video";
    case 3:
      return "Downloading Audio";
    case 4:
      return "Combining Audio and Video";
    case 5:
      return "Cleaning Segments";
    case 6:
      return "Uploading File";
    case 7:
      return "Complete";
    default:
      return "Unknown";
  }
}
function channelString(channel) {
  switch (channel) {
    case 0:
      return "BBC ONE HD";
    case 1:
      return "BBC ONE WALES HD";
    case 2:
      return "BBC ONE SCOTLAND HD";
    case 3:
      return "BBC ONE NORTHERN IRELAND HD";
    case 4:
      return "BBC ONE CHANNEL ISLANDS HD";
    case 5:
      return "BBC ONE EAST HD";
    case 6:
      return "BBC ONE EAST MIDLANDS HD";
    case 7:
      return "BBC ONE EAST YORKSHIRE & LINCOLNSHIRE HD";
    case 8:
      return "BBC ONE LONDON HD";
    case 9:
      return "BBC ONE NORTH EAST HD";
    case 10:
      return "BBC ONE NORTH WEST HD";
    case 11:
      return "BBC ONE SOUTH HD";
    case 12:
      return "BBC ONE SOUTH EAST HD";
    case 13:
      return "BBC ONE SOUTH WEST HD";
    case 14:
      return "BBC ONE WEST HD";
    case 15:
      return "BBC ONE WEST MIDLANDS HD";
    case 16:
      return "BBC ONE YORKSHIRE HD";
    case 17:
      return "BBC TWO HD";
    case 18:
      return "BBC TWO NORTHERN IRELAND HD";
    case 19:
      return "BBC TWO WALES DIGITAL";
    case 20:
      return "BBC THREE HD";
    case 21:
      return "BBC FOUR HD";
    case 22:
      return "CBBC HD";
    case 23:
      return "CBEEBIES HD";
    case 24:
      return "BBC SCOTLAND HD";
    case 25:
      return "BBC NEWS CHANNEL HD";
    case 26:
      return "BBC PARLIAMENT";
    case 27:
      return "BBC ALBA";
    case 28:
      return "S4C";
    default:
      return "Unknown";
  }
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const client = createClient("https://hlbdezevgntxspmvfmyv.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhsYmRlemV2Z250eHNwbXZmbXl2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTQzNTA1ODksImV4cCI6MjAyOTkyNjU4OX0.U1pYhVQLSPUegwEaeBwMcApFYMUKzkrQDYo8lkxBIac");
  const getRecordings = async () => {
    const { data: data2, error } = await client.from("recordings").select("*").limit(15).order("created_at", { ascending: false });
    if (error)
      console.log("error", error.message);
    return data2;
  };
  let { data } = $$props;
  let { form } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  if ($$props.form === void 0 && $$bindings.form && form !== void 0)
    $$bindings.form(form);
  return `<h2 data-svelte-h="svelte-1fcfh9e">BBCd2: Electric Boogaloo</h2> <p data-svelte-h="svelte-gjewfc">Not all affiliated with the original BBCd</p> <p data-svelte-h="svelte-1dm5cq3">All times now local to you!</p> <form method="POST"><div class="field label border round" data-svelte-h="svelte-v9uvsq"><input type="date" name="startDate" required> <label>Start Date</label></div> <div class="field label border round" data-svelte-h="svelte-12o6url"><input type="time" name="startTime" required> <label>Start Time</label></div> <div class="field label border round" data-svelte-h="svelte-x5npc6"><input type="date" name="endDate" required> <label>End Date</label></div> <div class="field label border round" data-svelte-h="svelte-1owrt9"><input type="time" name="endTime" required> <label>End Time</label></div> <div class="field label suffix border round"><select name="channel" required><option value=""></option><option value="0" data-svelte-h="svelte-171r8o3">BBC ONE HD</option><option value="1" data-svelte-h="svelte-1do2ns4">BBC ONE WALES HD</option><option value="2" data-svelte-h="svelte-d7rnor">BBC ONE SCOTLAND HD</option><option value="3" data-svelte-h="svelte-1e253j1">BBC ONE NORTHERN IRELAND HD</option><option value="4" data-svelte-h="svelte-eyzths">BBC ONE CHANNEL ISLANDS HD</option><option value="5" data-svelte-h="svelte-ldk1jn">BBC ONE EAST HD</option><option value="6" data-svelte-h="svelte-18vlc0g">BBC ONE EAST MIDLANDS HD</option><option value="7" data-svelte-h="svelte-ga21f1">BBC ONE EAST YORKSHIRE &amp; LINCOLNSHIRE HD</option><option value="8" data-svelte-h="svelte-16n62ez">BBC ONE LONDON HD</option><option value="9" data-svelte-h="svelte-mrzboi">BBC ONE NORTH EAST HD</option><option value="10" data-svelte-h="svelte-cu15wc">BBC ONE NORTH WEST HD</option><option value="11" data-svelte-h="svelte-7dhqzs">BBC ONE SOUTH HD</option><option value="12" data-svelte-h="svelte-8nz06y">BBC ONE SOUTH EAST HD</option><option value="13" data-svelte-h="svelte-ltrafh">BBC ONE SOUTH WEST HD</option><option value="14" data-svelte-h="svelte-1xitip7">BBC ONE WEST HD</option><option value="15" data-svelte-h="svelte-158pjqw">BBC ONE WEST MIDLANDS HD</option><option value="16" data-svelte-h="svelte-1b0qsqs">BBC ONE YORKSHIRE HD</option><option value="17" data-svelte-h="svelte-1ncz0ex">BBC TWO HD</option><option value="18" data-svelte-h="svelte-1t88j0f">BBC TWO NORTHERN IRELAND HD</option><option value="19" data-svelte-h="svelte-1l33ydx">BBC TWO WALES DIGITAL</option><option value="20" data-svelte-h="svelte-1hcxtc5">BBC THREE HD</option><option value="21" data-svelte-h="svelte-r5oi6y">BBC FOUR HD</option><option value="22" data-svelte-h="svelte-92txqy">CBBC HD</option><option value="23" data-svelte-h="svelte-1g82vn">CBEEBIES HD</option><option value="24" data-svelte-h="svelte-adgpz">BBC SCOTLAND HD</option><option value="25" data-svelte-h="svelte-1kbzm12">BBC NEWS CHANNEL HD</option><option value="26" data-svelte-h="svelte-q3kx3u">BBC PARLIAMENT</option><option value="27" data-svelte-h="svelte-1dimc4u">BBC ALBA</option><option value="28" data-svelte-h="svelte-zj4mdy">S4C</option></select> <label data-svelte-h="svelte-mgy5ef">Channel</label> <i data-svelte-h="svelte-1bv0s5u">arrow_drop_down</i></div> <button type="submit" data-svelte-h="svelte-1ou7dtz">Submit</button></form> <div class="space"></div> ${function(__value) {
    if (is_promise(__value)) {
      __value.then(null, noop);
      return ` <p data-svelte-h="svelte-13rvdoq">Fetching recordings...</p> `;
    }
    return function(recordings) {
      return ` <table class="border"><tr data-svelte-h="svelte-1i52pvu"><th>Start Time</th> <th>End Time</th> <th>Channel</th> <th>Status</th> <th>Download</th></tr> ${each(recordings, (recording) => {
        return `<tr><td>${escape(new Date(recording.rec_start * 1e3).toLocaleString("en-GB"))}</td> <td>${escape(new Date(recording.rec_end * 1e3).toLocaleString("en-GB"))}</td> <td>${escape(channelString(parseInt(recording.channel)))}</td> <td>${escape(statusString(recording.status))}</td> <td><a href="${"/express/download/" + escape(recording.uuid, true)}">Click</a></td> </tr>`;
      })}</table> `;
    }(__value);
  }(getRecordings())} <div id="snackbar" class="snackbar error" data-svelte-h="svelte-5ains8">Some text here</div>`;
});
export {
  Page as default
};
